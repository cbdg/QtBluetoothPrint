#ifndef COMMCONTROL_H
#define COMMCONTROL_H
#include <QByteArray>
#include <QtSerialPort/QSerialPort>
#include <QtSerialPort/QSerialPortInfo>
#include <iostream>
#include <math.h>
#include <QDebug>

class CommControl
{
public:
    CommControl();
    enum HorPos { Left, Center, Right };
    int ColWidth = 47;
    QSerialPort *serialPort;
    bool Dispose();
    bool IsOpen();
     bool Write(QByteArray bdata);
     bool Write(QString Data);
     bool WriteLine(QString Data);
     bool PrintLine();
     bool NewRow();
     bool NewRow(int iRow);
     bool CutPaper();
     bool SetNormalFont();
     bool WriteBigLine(QString Data);
     bool WriteLittleBigLine(QString Data);

private:
      volatile bool com_opened;
      volatile bool stopped;
};

#endif // COMMCONTROL_H
