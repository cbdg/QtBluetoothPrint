#include <QCoreApplication>
#include <QString>
#include <iostream>
#include <QDateTime>
#include "commcontrol.h"



int main(int argc, char *argv[])
{
    QCoreApplication a(argc, argv);
    CommControl commcon;
                if (commcon.IsOpen())
                {
                    QDateTime current_date_time = QDateTime::currentDateTime();
                    QString current_date = "            "+current_date_time.toString("yyyy-MM-dd ddd hh:mm:ss");
                    QString truenumber="No:001";
                    commcon.WriteLittleBigLine(truenumber);
                    commcon.WriteBigLine("    15元");
                     commcon.PrintLine();
                     commcon.WriteLine("             孵客创业餐厅欢迎您！");
                     commcon.WriteLine(current_date);
                     commcon.WriteLine("             当日有效，过期作废！");
                     commcon.NewRow(5);

                     commcon.CutPaper();

                }
                commcon.Dispose();
    return a.exec();
}

