#include "commcontrol.h"
enum Excep
{
EXCEP_ONE,
EXCEP_TWO
};
CommControl::CommControl()
{
    serialPort=new QSerialPort;
    stopped=false;
        if(stopped&&com_opened)
        {
            serialPort->close();
            com_opened=false;

        }
        if(!com_opened)
        {
            //open com
           // qDebug() << "Brush:" <<"---open com port------";
            com_opened=true;
            serialPort->setPortName("COM1");
            serialPort->open(QIODevice::ReadWrite);
            serialPort->setBaudRate(19200);
            serialPort->setDataBits(QSerialPort::Data8);
            serialPort->setParity(QSerialPort::NoParity);
            serialPort->setStopBits(QSerialPort::OneStop);
            // my_serialport->setStopBits(QSerialPort::TwoStop);
            serialPort->setFlowControl(QSerialPort::NoFlowControl);
            com_opened=true;
            SetNormalFont();
        }

}

bool CommControl::Dispose()
{\
    bool Result = true;


        if (serialPort->isOpen())
        {
            try
            {
                serialPort->close();
                delete serialPort;
                //serialPort->

            }
            catch(Excep ex)
            { Result = false; }
        }


    return Result;
}



bool CommControl::IsOpen()
{
    bool Result = false;
   // serialPort.Encoding = System.Text.Encoding.GetEncoding("GB2312");
    if (serialPort->isOpen()) Result = true;
    return Result;

}


bool CommControl::Write(QByteArray bdata)
{
    try
    {
        if (IsOpen())
        {
            serialPort->write(bdata);
            serialPort->waitForBytesWritten(-1);
            qDebug()<<"send success";
            return true;
        }
        else
        {
            return false;
        }
    }
    catch(Excep ex)
    { return false; }
}


bool CommControl::Write(QString Data)
{
    try
    {
        if (IsOpen())
        {
            QByteArray bData = Data.toLocal8Bit();
            Write(bData);
            return true;
        }
        else
        {
            return false;
        }
    }
    catch(Excep ex) { return false; }
}


bool CommControl::WriteLine(QString Data)
{
    bool Result = Write(Data);
    if (Result) Result = NewRow();
    return Result;
}




bool CommControl::PrintLine()
{
     return WriteLine("=============================================");
}


bool CommControl::NewRow()
{
     QByteArray temp;
     temp.resize(1);
     temp[0]=0x0A;
     return Write(temp);
}



bool CommControl::NewRow(int iRow)
{
    bool Result = false;
    for (int i = 0; i < iRow; i++)
    {
        Result = NewRow();
        if (!Result) break;
    }
    return Result;
}



bool CommControl::CutPaper()
{
    QByteArray temp;
    temp.resize(3);
    temp[0]=0x1D;
    temp[1]=0x56;
    temp[2]=0x00;
    qDebug()<<temp;
    return Write(temp);
}



bool CommControl::SetNormalFont()
{
    if (!IsOpen()) return false;
    QByteArray temp;
    try
    {
        //1D, 50 设置横向和纵向移动单位
        temp.resize(4);
        temp[0]=0x1D;
        temp[1]=0x50;
        temp[2]=0xB4;
        temp[3]=0xB4;
        serialPort->write(temp);
        //1B, 53 选择标准模式
        temp.resize(2);
        temp[0]=0x1B;
        temp[1]=0x53;
        serialPort->write(temp);
        //1B, 20 设置字符右间距
        temp.resize(3);
        temp[0]=0x1B;
        temp[1]=0x20;
        temp[2]=0x00;
        serialPort->write(temp);
        //设置汉字字符左右间距
        temp.resize(4);
        temp[0]=0x1C;
        temp[1]=0x53;
        temp[2]=0x00;
        temp[3]=0x00;
        serialPort->write(temp);
        //1D 42 是否反选打印 01反选/00取消
        temp.resize(3);
        temp[0]=0x1D;
        temp[1]=0x42;
        temp[2]=0x00;
        serialPort->write(temp);
        //1B 45 选择/取消加粗模式 01选择/00取消////////////
        //temp = { 0x1B, 0x45, 0x00 };
        //serialPort->write(temp);
        //1B 7B 选择/取消倒置打印模式 01选择/00取消
        temp.resize(3);
        temp[0]=0x1B;
        temp[1]=0x7B;
        temp[2]=0x00;
        serialPort->write(temp);
        //1B 2D 设置/取消下划线 01设置/00取消
        temp.resize(3);
        temp[0]=0x1B;
        temp[1]=0x2D;
        temp[2]=0x00;
        serialPort->write(temp);
        //1B 2D 设置/取消汉字下划线 01设置/00取消
        temp.resize(3);
        temp[0]=0x1C;
        temp[1]=0x2D;
        temp[2]=0x00;
        serialPort->write(temp);
        //选择取消顺时针旋转90度 01选择 00取消
        temp.resize(3);
        temp[0]=0x1B;
        temp[1]=0x56;
        temp[2]=0x00;
        serialPort->write(temp);
        //1B 45 选择/取消加粗模式 01选择/00取消
        temp.resize(3);
        temp[0]=0x1B;
        temp[1]=0x45;
        temp[2]=0x00;
        serialPort->write(temp);
        //1B 24 设置绝对打印位置
        temp.resize(4);
        temp[0]=0x1B;
        temp[1]=0x24;
        temp[2]=0x00;
        temp[3]=0x00;
        serialPort->write(temp);

        //1B, 33 设置行高, 18个像素
        temp.resize(3);
        temp[0]=0x1B;
        temp[1]=0x33;
        temp[2]=0x20;
        serialPort->write(temp);
        //1B 4D 选择字体 03为汉字字体/////////
        temp.resize(3);
        temp[0]=0x1B;
        temp[1]=0x4D;
        temp[2]=0x00;
        serialPort->write(temp);
        //1D 21 选择字体大小,默认
        temp.resize(3);
        temp[0]=0x1D;
        temp[1]=0x21;
        temp[2]=0x00;
        serialPort->write(temp);
        return true;
    }
    catch(Excep ex) { return false; }

}




bool CommControl::WriteBigLine(QString Data)
{
    bool Result = true;
    //Result = SetNormalFont();
    if (!Result) return Result;
    try
    {
        QByteArray temp;
        //1B, 33 设置行高, 54个像素
        temp.resize(3);
        temp[0]=0x1B;
        temp[1]=0x33;
        temp[2]=0x48;
        serialPort->write(temp);
        serialPort->waitForBytesWritten(-1);
        //1B 4D 选择字体 03为汉字字体
        temp.resize(3);
        temp[0]=0x1B;
        temp[1]=0x4D;
        temp[2]=0x03;
        serialPort->write(temp);
        serialPort->waitForBytesWritten(-1);
        //横向放大和纵向放大不可同时作用
        //1D 21 选择字体大小,横向放大1倍
        //temp = { 0x1D, 0x21, 0x10 };
        //serialPort->write(temp);
        //1D 21 选择字体大小,纵向放大1倍
        temp.resize(3);
        temp[0]=0x1D;
        temp[1]=0x21;
        temp[2]=0x33;
        serialPort->write(temp);
        serialPort->waitForBytesWritten(-1);
        //1B 45 选择/取消加粗模式 01选择/00取消
        temp.resize(3);
        temp[0]=0x1B;
        temp[1]=0x45;
        temp[2]=0x01;
        serialPort->write(temp);
        serialPort->waitForBytesWritten(-1);
        Write(Data);
        Result = true;
    }
    catch(Excep ex) { Result = false; }
    Result = SetNormalFont();
    if (Result) Result = NewRow();
    return Result;
}

bool CommControl::WriteLittleBigLine(QString Data)
{
    bool Result = true;
    //Result = SetNormalFont();
    if (!Result) return Result;
    try
    {
        QByteArray temp;
        //1B, 33 设置行高, 54个像素
        temp.resize(3);
        temp[0]=0x1B;
        temp[1]=0x33;
        temp[2]=0x48;
        serialPort->write(temp);
        serialPort->waitForBytesWritten(-1);
        //1B 4D 选择字体 03为汉字字体
        temp.resize(3);
        temp[0]=0x1B;
        temp[1]=0x4D;
        temp[2]=0x03;
        serialPort->write(temp);
        serialPort->waitForBytesWritten(-1);
        //横向放大和纵向放大不可同时作用
        //1D 21 选择字体大小,横向放大1倍
        //temp = { 0x1D, 0x21, 0x10 };
        //serialPort->write(temp);
        //1D 21 选择字体大小,纵向放大1倍
        temp.resize(3);
        temp[0]=0x1D;
        temp[1]=0x21;
        temp[2]=0x11;
        serialPort->write(temp);
        serialPort->waitForBytesWritten(-1);
        //1B 45 选择/取消加粗模式 01选择/00取消
        temp.resize(3);
        temp[0]=0x1B;
        temp[1]=0x45;
        temp[2]=0x01;
        serialPort->write(temp);
        serialPort->waitForBytesWritten(-1);
        Write(Data);
        Result = true;
    }
    catch(Excep ex) { Result = false; }
    Result = SetNormalFont();
    if (Result) Result = NewRow();
    return Result;
}


