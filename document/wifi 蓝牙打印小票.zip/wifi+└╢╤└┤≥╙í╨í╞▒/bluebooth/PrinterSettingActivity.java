package kangwei.example.com.storemanager.bluebooth;

import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.provider.Settings;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import com.google.gson.Gson;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.UnknownHostException;
import java.util.List;
import kangwei.example.com.storemanager.R;
import kangwei.example.com.storemanager.bean.ListBean;
import kangwei.example.com.storemanager.bean.ObjBean;
import kangwei.example.com.storemanager.bean.ParentBean;
import kangwei.example.com.storemanager.bean.Root;
import kangwei.example.com.storemanager.utils.HttpUtil;
import kangwei.example.com.storemanager.utils.Pos;
import kangwei.example.com.storemanager.utils.ToastUtil;

public class PrinterSettingActivity extends BasePrintActivity implements View.OnClickListener{
    private Root root;
    private String result;
    private ObjBean obj;
    private ObjBean objBean;
    private List<ParentBean> foodsBean;
    private List<ListBean> listBeen;
    ListView mLvPairedDevices;
    Button mBtnSetting;
    Button mBtnTest;
    Button mBtnPrint;

    DeviceListAdapter mAdapter;
    int mSelectedPosition = -1;

    final static int TASK_TYPE_CONNECT = 1;
    final static int TASK_TYPE_PRINT = 2;

    private String id;
    private Pos pos;
    private OutputStream mOutputStream = null;
    private Bitmap head_bitmap;
    private Bitmap code_bitmap;
    private LinearLayout back;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_printer_setting);
        id = getIntent().getStringExtra("id");
        setTitle("蓝牙打印");
        initViews();
        print();//获取小票数据
    }


        private void print() {
            HttpUtil.ticket(this, id, new HttpUtil.KWiListener() {
                @Override
                public void onResult(int ret, Object msg) {
                    Log.d("tag", "打印小票： " + msg.toString());
                    Gson gson = new Gson();
                    String jsonString = msg.toString();
                    root = gson.fromJson(jsonString, Root.class);
                    result = root.getResult().getResultCode();
                    if (result.equals("0")) {
                        objBean = root.getObj();
                        foodsBean = objBean.getParent();

                    } else {
                        ToastUtil.show(root.getResult().getResultMessage());
                    }
                }
            });
        }


    @Override
    protected void onResume() {
        super.onResume();
        fillAdapter();
    }

    private void initViews() {
        back = (LinearLayout) findViewById(R.id.back);
        back.setOnClickListener(this);
        mLvPairedDevices = (ListView) findViewById(R.id.lv_paired_devices);
        mBtnSetting = (Button) findViewById(R.id.btn_goto_setting);
        mBtnTest = (Button) findViewById(R.id.btn_test_conntect);
        mBtnPrint = (Button) findViewById(R.id.btn_print);

        mLvPairedDevices.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                mSelectedPosition = position;
                mAdapter.notifyDataSetChanged();
            }
        });

        mBtnSetting.setOnClickListener(this);
        mBtnTest.setOnClickListener(this);
        mBtnPrint.setOnClickListener(this);

        mAdapter = new DeviceListAdapter(this);
        mLvPairedDevices.setAdapter(mAdapter);
    }

    /**
     * 从所有已配对设备中找出打印设备并显示
     */
    private void fillAdapter() {
        //推荐使用 BluetoothUtil.getPairedPrinterDevices()
        List<BluetoothDevice> printerDevices = BluetoothUtil.getPairedDevices();
        mAdapter.clear();
        mAdapter.addAll(printerDevices);
        refreshButtonText(printerDevices);
    }

    private void refreshButtonText(List<BluetoothDevice> printerDevices) {
        if (printerDevices.size() > 0) {
            mBtnSetting.setText("配对更多设备");
        } else {
            mBtnSetting.setText("还未配对打印机，去设置");
        }
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.btn_goto_setting:
                startActivity(new Intent(Settings.ACTION_BLUETOOTH_SETTINGS));
                break;

            case R.id.btn_test_conntect:
                connectDevice(TASK_TYPE_CONNECT);
                break;

            case R.id.btn_print:
                connectDevice(TASK_TYPE_PRINT);
                break;
            case R.id.back:
                finish();
                break;
            default:
                break;
        }
    }

    private void connectDevice(int taskType){
        if(mSelectedPosition >= 0){
            BluetoothDevice device = mAdapter.getItem(mSelectedPosition);
            if(device!= null)
                super.connectDevice(device, taskType);
        }else{
            Toast.makeText(this, "还未选择打印设备", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onConnected(BluetoothSocket socket, int taskType) {
        switch (taskType){
            case TASK_TYPE_PRINT:
                if(socket != null&&socket.isConnected()){
                    pos(socket);
                }

                break;
        }
    }

    private void pos(final BluetoothSocket socket) {
        // 开启一个子线程
        new Thread() {
            public void run() {
                try {
                    //初始化打印机
                    pos = new Pos(socket.getOutputStream(),"GBK");
                    if (!TextUtils.isEmpty(objBean.getHead_img())){
                        pos.printLocation(1);
                        head_bitmap = pos.compressPic(returnBitMap(objBean.getHead_img()));
                        pos.draw2PxPoint(head_bitmap);
                    }
                    pos.printLocation(1);
                    pos.bold(true);
                    pos.printTabSpace(2);
                    pos.printWordSpace(1);
                    pos.printTextNewLine(objBean.getShop_name());

                    pos.printLocation(0);
                    pos.printTextNewLine("----------------------------------------------");
                    pos.bold(false);
                    pos.printTextNewLine("订 单 号："+objBean.getSn());
                    pos.printTextNewLine("用 户 名："+objBean.getMember());
                    pos.printTextNewLine("订单日期："+objBean.getCreate_time());
                    pos.printTextNewLine("支付方式："+objBean.getPay_way());
                    pos.printTextNewLine("订单折扣："+objBean.getDiscount());
                    pos.printTextNewLine("订单备注："+objBean.getRemarks());
                    pos.printLine(2);

                    pos.printText("货号          尺码    颜色    数量   小计");
                    pos.printLocation(20, 1);
                    pos.printTextNewLine("----------------------------------------------");

                    for (ParentBean foods : foodsBean) {
                        pos.printTextNewLine(foods.getGoods_name()+"          "+foods.getCode_number()+"     "+foods.getColour()+"      "+foods.getNum()+"      "+foods.getPay_back());
                        pos.printLocation(20, 1);

                    }

                    pos.printTextNewLine("----------------------------------------------");
                    pos.printLocation(0);
                    pos.printLine(1);
                    pos.printTextNewLine("订单总数："+objBean.getNums());
                    pos.printTextNewLine("应收金额："+objBean.getActual_pay());
                    pos.printTextNewLine("优惠金额："+objBean.getDiscount_pay());
                    pos.printTextNewLine("实收金额："+objBean.getPay());
                    pos.printLine(2);
                    //打印二维码  -- 如果提供了二维码的地址则用该方法
//                  pos.qrCode(objBean.getQr_code());


                    //打印二维码的图片 -- 如果提供了二维码的截图则用该方法
                    if (!TextUtils.isEmpty(objBean.getQr_code())){
                        pos.printLocation(1);
                        code_bitmap = pos.compressPic(returnBitMap(objBean.getQr_code()));
                        pos.draw2PxPoint(code_bitmap);
                    }
                    pos.printLine(4);
                    //切纸
                    pos.feedAndCut();
//                  pos.closeIOAndSocket();
                    pos = null;
                } catch (UnknownHostException e) {
                    Log.d("tag", "错误信息1：" + e.toString());
                } catch (IOException e) {
                    Log.d("tag", "错误信息2：" + e.toString());
                }
            }

        }.start();

    }
    class DeviceListAdapter extends ArrayAdapter<BluetoothDevice> {

        public DeviceListAdapter(Context context) {
            super(context, 0);
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {

            BluetoothDevice device = getItem(position);
            if (convertView == null) {
                convertView = LayoutInflater.from(getContext()).inflate(R.layout.item_bluetooth_device, parent, false);
            }

            TextView tvDeviceName = (TextView) convertView.findViewById(R.id.tv_device_name);
            CheckBox cbDevice = (CheckBox) convertView.findViewById(R.id.cb_device);

            tvDeviceName.setText(device.getName());

            cbDevice.setChecked(position == mSelectedPosition);

            return convertView;
        }
    }
    public Bitmap returnBitMap(String url) {
        URL myFileUrl = null;
        Bitmap bitmap = null;
        try {
            myFileUrl = new URL(url);
        } catch (MalformedURLException e) {
            e.printStackTrace();
        }
        try {
            HttpURLConnection conn = (HttpURLConnection) myFileUrl.openConnection();
            conn.setDoInput(true);
            conn.connect();
            InputStream is = conn.getInputStream();
            bitmap = BitmapFactory.decodeStream(is);
            is.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return bitmap;
    }
}
