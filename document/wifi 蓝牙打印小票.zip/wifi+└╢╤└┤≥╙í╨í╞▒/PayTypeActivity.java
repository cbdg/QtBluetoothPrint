package kangwei.example.com.storemanager.sales;

import android.bluetooth.BluetoothAdapter;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import com.google.gson.Gson;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.Socket;
import java.net.URL;
import java.net.UnknownHostException;
import java.util.List;
import kangwei.example.com.storemanager.R;
import kangwei.example.com.storemanager.base.BaseActivity;
import kangwei.example.com.storemanager.bean.ListBean;
import kangwei.example.com.storemanager.bean.ObjBean;
import kangwei.example.com.storemanager.bean.ParentBean;
import kangwei.example.com.storemanager.bean.Root;
import kangwei.example.com.storemanager.bluebooth.BluetoothService;
import kangwei.example.com.storemanager.bluebooth.PrinterSettingActivity;
import kangwei.example.com.storemanager.utils.HttpUtil;
import kangwei.example.com.storemanager.utils.Pos;
import kangwei.example.com.storemanager.utils.Preference;
import kangwei.example.com.storemanager.utils.ToastUtil;

public class PayTypeActivity extends BaseActivity {
    private LinearLayout cash;
    private LinearLayout back;
    private String remarks;
    private String id;
    private String pay;
    private String discount;
    private String type;
    private String shop_type;
    private Root root;
    private String result;
    private ObjBean obj;
    private ObjBean objBean;
    private List<ListBean> listBeen;
    private TextView price;
    private String pay_id;
    private String spec_id;
    private String num;
    private String goods_id;
    private RelativeLayout ll_pay;
    private TextView price_pay;

    private TextView right;
    private Button submit;
    private Pos pos;
    private TextView change;
//    //订单菜品集合
    private List<ParentBean> foodsBean;
    private LinearLayout ll_wechat;
    private LinearLayout ll_alipay;
    private LinearLayout ll_card;
    private LinearLayout ll_other;
    private String paying = "0";//未收款
    private EditText phone;
    private EditText username;
    private String member_id;
    private Bitmap bitmap;
    private Bitmap Qbitmap;
    private Socket socket;
    private OutputStream os;
    private byte[] buffer;
    private LinearLayout ll_add;
    private TextView right_blue;

    public static final int MESSAGE_STATE_CHANGE = 1;
    public static final int MESSAGE_READ = 2;
    public static final int MESSAGE_WRITE = 3;
    public static final int MESSAGE_DEVICE_NAME = 4;
    public static final int MESSAGE_TOAST = 5;

    // Key names received from the BluetoothService Handler
    public static final String DEVICE_NAME = "device_name";
    public static final String TOAST = "toast";

    // Intent request codes
    private static final int REQUEST_CONNECT_DEVICE = 1;
    private static final int REQUEST_ENABLE_BT = 2;

    // Name of the connected device
    private String mConnectedDeviceName = null;
    // String buffer for outgoing messages
    private StringBuffer mOutStringBuffer;
    // Local Bluetooth adapter
    private BluetoothAdapter mBluetoothAdapter = null;
    // Member object for the services
    public static BluetoothService mService = null;
    private String blue_type ="0";


        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_pay_type);     
            id = getIntent().getStringExtra("id");     
            initview();
        }
    @Override
    public void onStart() {
        super.onStart();

    }

        private void initview() {
            right_blue = (TextView) findViewById(R.id.right_blue);
            right_blue.setOnClickListener(this);
            right = (TextView) findViewById(R.id.right);
            right.setOnClickListener(this);
            back = (LinearLayout) findViewById(R.id.back);
            back.setOnClickListener(this);
 

        }

        @Override
        public void onClick(View v) {
            switch (v.getId()) {
                case R.id.back:
                    finish();
                    break;
                case R.id.right://wifi打印
                    pos();
                    break;
                case R.id.right_blue://蓝牙打印
                    Intent right_blue = new Intent(this, PrinterSettingActivity.class);
                    right_blue.putExtra("id",obj.getId());
                    startActivity(right_blue);
                    break;
        
            }
        }

    private void pos() {
        // 开启一个子线程
        new Thread() {
            public void run() {
                try {              //打印机网口IP    打印机端口号     编码方式
                    pos = new Pos(Preference.instance(PayTypeActivity.this).getIPAddress(), Integer.parseInt(Preference.instance(PayTypeActivity.this).getPost_IDs()), "gbk");
                    //初始化打印机
                    pos.initPos();
                    if (!TextUtils.isEmpty(objBean.getHead_img())){
                        pos.printLocation(1);
                        bitmap = pos.compressPic(returnBitMap(objBean.getHead_img()));
                        pos.draw2PxPoint(bitmap);
                    }
                    pos.printLocation(1);
                    pos.bold(true);
                    pos.printTabSpace(2);
                    pos.printWordSpace(1);
                    pos.printTextNewLine(objBean.getShop_name());

                    pos.printLocation(0);
                    pos.printTextNewLine("----------------------------------------------");
                    pos.bold(false);
                    pos.printTextNewLine("订 单 号："+objBean.getSn());
                    pos.printTextNewLine("用 户 名："+objBean.getMember());
                    pos.printTextNewLine("订单日期："+objBean.getCreate_time());
                    pos.printTextNewLine("支付方式："+objBean.getPay_way());
                    pos.printTextNewLine("订单折扣："+objBean.getDiscount());
                    pos.printTextNewLine("订单备注："+objBean.getRemarks());
                    pos.printLine(2);

                    pos.printText("货号          尺码    颜色    数量   小计");
                    pos.printLocation(20, 1);
                    pos.printTextNewLine("----------------------------------------------");

                    for (ParentBean foods : foodsBean) {
                        pos.printTextNewLine(foods.getGoods_name()+"          "+foods.getCode_number()+"     "+foods.getColour()+"      "+foods.getNum()+"      "+foods.getPay_back());
                        pos.printLocation(20, 1);
                    }

                    pos.printTextNewLine("----------------------------------------------");
                    pos.printLocation(0);
                    pos.printLine(1);
                    pos.printTextNewLine("订单总数："+objBean.getNums());
                    pos.printTextNewLine("应收金额："+objBean.getActual_pay());
                    pos.printTextNewLine("优惠金额："+objBean.getDiscount_pay());
                    pos.printTextNewLine("实收金额："+objBean.getPay());
                    pos.printLine(2);

//                    //打印二维码  -- 如果提供了二维码的地址则用该方法
//                    pos.qrCode(objBean.getQr_code());

                    //打印二维码的图片 -- 如果提供了二维码的截图则用该方法
                    if (!TextUtils.isEmpty(objBean.getQr_code())){
                        pos.printLocation(1);
                        Qbitmap = pos.compressPic(returnBitMap(objBean.getQr_code()));//url 转换为bitmap
                        pos.draw2PxPoint(Qbitmap);
                    }
                    //切纸
                    pos.feedAndCut();
                    pos.closeIOAndSocket();
                    pos = null;
                } catch (UnknownHostException e) {
                    e.printStackTrace();
                    showToast(e.toString());
                    Log.d("tag", "错误信息1：" + e.toString());
                } catch (IOException e) {
                    e.printStackTrace();
                    showToast(e.toString());
                    Log.d("tag", "错误信息2：" + e.toString());
                }
            }

        }.start();

    }

    public Bitmap returnBitMap(String url) {
        URL myFileUrl = null;
        Bitmap bitmap = null;
        try {
            myFileUrl = new URL(url);
        } catch (MalformedURLException e) {
            e.printStackTrace();
        }
        try {
            HttpURLConnection conn = (HttpURLConnection) myFileUrl.openConnection();
            conn.setDoInput(true);
            conn.connect();
            InputStream is = conn.getInputStream();
            bitmap = BitmapFactory.decodeStream(is);
            is.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return bitmap;
    }

}
